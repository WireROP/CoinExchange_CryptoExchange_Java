package com.bizzan.bitrade.dao;

import com.bizzan.bitrade.dao.base.BaseDao;
import com.bizzan.bitrade.entity.LegalWalletRecharge;

public interface LegalWalletRechargeDao extends BaseDao<LegalWalletRecharge> {
}
