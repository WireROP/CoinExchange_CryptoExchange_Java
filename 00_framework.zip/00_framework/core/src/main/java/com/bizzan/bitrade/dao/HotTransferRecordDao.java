package com.bizzan.bitrade.dao;

        import com.bizzan.bitrade.dao.base.BaseDao;
import com.bizzan.bitrade.entity.HotTransferRecord;

public interface HotTransferRecordDao extends BaseDao<HotTransferRecord> {
}
